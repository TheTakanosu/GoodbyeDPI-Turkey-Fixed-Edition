@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Mimari Kontrolü (Architecture Check)
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo      GOODBYEDPI v1.0.1 ELITE - SUPERONLINE ALT-2
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak uygulama baslatiliyor. (Alternatif Metod 2)
echo Bu batch dosyasini yonetici olarak calistirmanız onerilir.
echo.
echo [!] NOT: Islem basladiktan sonra Windows ayarlarindan DNS
echo     degistirmeyi ve tarayicinizi yeniden baslatmayi unutmayin.
echo [!] Bu pencereyi kapattiginizda koruma sona erer.
echo.
echo Devam etmek icin herhangi bir tusa basin.
pause >nul

:: Dosya Yolları (Absolute Paths for Elite Stability)
SET "EXE_PATH=%CD%\%_arch%\goodbyedpi.exe"
SET "LIST_PATH=%CD%\turkey-blacklist.txt"

:: Uygulama Baslatma: Saf Mod-5 ve Blacklist Yapilandirmasi
start "" "%EXE_PATH%" -5 --blacklist "%LIST_PATH%"

echo.
echo [+] Islem Basariyla Tamamlandi. Iyi oyunlar!
timeout /t 3 >nul
POPD