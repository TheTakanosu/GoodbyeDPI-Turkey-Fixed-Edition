@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Mimari Kontrolü (Architecture Check)
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo        GOODBYEDPI v1.0.1 ELITE - DETAILED BASE
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak hizmeti yuklemek icin:
echo Bu batch dosyasini yonetici olarak calistirmaniz gerekmektedir.
echo Sag Tik - Yonetici Olarak Calistir.
echo.
echo Eger yonetici olarak calistirdiysaniz herhangi bir tusa basin.
echo Bu metodu kullaniyorsaniz ayrica Windows ayarlarindan DNS degistirmenize gerek yoktur.
pause >nul

:: Mevcut servisi temizle (Clean up existing service)
sc stop "GoodbyeDPI" >nul 2>&1
sc delete "GoodbyeDPI" >nul 2>&1

:: Temel Yandex DNS ve Blacklist Yapılandırması (v4 & v6 Optimized)
SET "BIN_PATH=\"%CD%\%_arch%\goodbyedpi.exe\" -5 --set-ttl 5 --dns-addr 77.88.8.8 --dns-port 1253 --dnsv6-addr 2a02:6b8::feed:0ff --dnsv6-port 1253 --blacklist \"%CD%\turkey-blacklist.txt\""

sc create "GoodbyeDPI" binPath= "!BIN_PATH!" start= "auto" >nul
sc description "GoodbyeDPI" "Turkiye icin optimize edilmis, oyun dostu internet servisi." >nul
sc start "GoodbyeDPI" >nul

echo.
echo [+] Islem Tamamlandi. Temel servis Superonline icin aktif edildi.
timeout /t 3 >nul
POPD