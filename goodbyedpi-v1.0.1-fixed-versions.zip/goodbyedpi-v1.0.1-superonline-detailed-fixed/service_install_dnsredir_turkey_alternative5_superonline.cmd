@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Mimari Kontrolü (Architecture Check)
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo      GOODBYEDPI v1.0.1 ELITE - SUPERONLINE ALT-5
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak hizmeti yuklemek icin: (Alternatif Metod 5)
echo Bu batch dosyasini yonetici olarak calistirmaniz gerekmektedir.
echo Sag Tik - Yonetici Olarak Calistir.
echo.
echo Eger yonetici olarak calistirdiysaniz herhangi bir tusa basin.
pause >nul

:: Mevcut servisi temizle (Clean up existing service)
sc stop "GoodbyeDPI" >nul 2>&1
sc delete "GoodbyeDPI" >nul 2>&1

:: Alt-5: Agresif Mod-9, Yandex DNS ve Blacklist Yapilandirmasi (Elite Absolute Path)
SET "BIN_PATH=\"%CD%\%_arch%\goodbyedpi.exe\" -9 --dns-addr 77.88.8.8 --dns-port 1253 --blacklist \"%CD%\turkey-blacklist.txt\""

sc create "GoodbyeDPI" binPath= "!BIN_PATH!" start= "auto" >nul
sc description "GoodbyeDPI" "Superonline icin optimize edilmis alternatif servis 5." >nul
sc start "GoodbyeDPI" >nul

echo.
echo [+] Alternatif-5 servisi basariyla kuruldu.
timeout /t 3 >nul
POPD