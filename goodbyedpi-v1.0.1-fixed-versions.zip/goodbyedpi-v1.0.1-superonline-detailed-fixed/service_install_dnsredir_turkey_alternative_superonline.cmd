@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Mimari Kontrolü (Architecture Check)
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo      GOODBYEDPI v1.0.1 ELITE - SUPERONLINE ALT-1
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak hizmeti yuklemek icin: (Alternatif Metod)
echo Bu batch dosyasini yonetici olarak calistirmaniz gerekmektedir.
echo.
echo [!] NOT: Islem bittikten sonra Windows ayarlarindan DNS degistirmeyi
echo     ve bilgisayarinizi yeniden baslatmayi unutmayin.
echo.
echo Devam etmek icin herhangi bir tusa basin...
pause >nul

:: Mevcut servisi temizle (Clean up existing service)
sc stop "GoodbyeDPI" >nul 2>&1
sc delete "GoodbyeDPI" >nul 2>&1

:: Alt-1: Dusuk TTL ve Blacklist Yapilandirmasi (Elite Absolute Path)
SET "BIN_PATH=\"%CD%\%_arch%\goodbyedpi.exe\" --set-ttl 3 --blacklist \"%CD%\turkey-blacklist.txt\""

sc create "GoodbyeDPI" binPath= "!BIN_PATH!" start= "auto" >nul
sc description "GoodbyeDPI" "Superonline icin optimize edilmis alternatif servis." >nul
sc start "GoodbyeDPI" >nul

echo.
echo [+] Alternatif-1 servisi basariyla kuruldu.
timeout /t 3 >nul
POPD