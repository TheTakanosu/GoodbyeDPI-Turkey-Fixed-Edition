@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Mimari Kontrolü (Architecture Check)
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo      GOODBYEDPI v1.0.1 ELITE - SUPERONLINE ALT-5
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak uygulama baslatiliyor. (Alternatif Metod 5)
echo Bu batch dosyasini yonetici olarak calistirmanız onerilir.
echo.
echo [!] NOT: Bu pencereyi kapattiginizda koruma sona erer.
echo [!] Ayrica Windows ayarlarindan DNS degistirmenize gerek yoktur.
echo.
echo Devam etmek icin herhangi bir tusa basin.
pause >nul

:: Dosya Yolları (Absolute Paths for Elite Stability)
SET "EXE_PATH=%CD%\%_arch%\goodbyedpi.exe"
SET "LIST_PATH=%CD%\turkey-blacklist.txt"

:: Uygulama Baslatma: Agresif Mod-9, Yandex DNS ve Blacklist Yapilandirmasi
start "" "%EXE_PATH%" -9 --dns-addr 77.88.8.8 --dns-port 1253 --blacklist "%LIST_PATH%"

echo.
echo [+] Islem Basariyla Tamamlandi. Iyi oyunlar!
timeout /t 3 >nul
POPD