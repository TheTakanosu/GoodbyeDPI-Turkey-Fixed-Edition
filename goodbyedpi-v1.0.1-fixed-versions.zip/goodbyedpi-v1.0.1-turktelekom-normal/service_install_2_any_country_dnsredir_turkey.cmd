@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Mimari Kontrolü (Architecture Check)
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo        GOODBYEDPI v1.0.1 ELITE - SERVICE INSTALLER
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak hizmeti yuklemek icin:
echo Bu batch dosyasini yonetici olarak calistirmaniz gerekmektedir.
echo Sag Tik - Yonetici Olarak Calistir.
echo.
echo Eger yonetici olarak calistirdiysaniz herhangi bir tusa basin.
echo Bu metodu kullaniyorsaniz ayrica Windows ayarlarindan DNS degistirmenize gerek yoktur.
pause >nul

:: Mevcut servisi temizle (Clean up existing service)
sc stop "GoodbyeDPI" >nul 2>&1
sc delete "GoodbyeDPI" >nul 2>&1

:: Dosya Yolları ve Parametreler (Absolute Paths for Elite Stability)
SET "EXE_FULL_PATH=%CD%\%_arch%\goodbyedpi.exe"
SET "LIST_FULL_PATH=%CD%\turkey-blacklist.txt"

:: Servis Olusturma ve Baslatma (Türk Telekom / Yandex DNS v4 & v6 Optimized)
sc create "GoodbyeDPI" binPath= "\"%EXE_FULL_PATH%\" -5 --set-ttl 5 --blacklist \"%LIST_FULL_PATH%\" --dns-addr 77.88.8.8 --dns-port 1253 --dnsv6-addr 2a02:6b8::feed:0ff --dnsv6-port 1253" start= "auto"
sc description "GoodbyeDPI" "Turkiye icin optimize edilmis, oyun dostu internet servisi."
sc start "GoodbyeDPI"

echo.
echo [+] Islem Tamamlandi. Turk Telekom icin servis aktif edildi.
timeout /t 3 >nul
POPD