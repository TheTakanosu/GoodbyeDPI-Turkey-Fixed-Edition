@ECHO OFF
SETLOCAL EnableDelayedExpansion
PUSHD "%~dp0"

:: Architecture check
SET "_arch=x86"
IF "%PROCESSOR_ARCHITECTURE%"=="AMD64" SET "_arch=x86_64"
IF DEFINED PROCESSOR_ARCHITEW6432 SET "_arch=x86_64"

echo ========================================================
echo        GOODBYEDPI v1.0.1 ELITE - SERVICE INSTALLER
echo ========================================================
echo.
echo DNS zorlamasini kaldiracak hizmeti yuklemek icin:
echo Bu batch dosyasini yonetici olarak calistirmaniz gerekmektedir.
echo.
echo Eger yonetici olarak calistirdiysaniz herhangi bir tusa basin.
pause >nul

:: Clean up existing service
sc stop "GoodbyeDPI" >nul 2>&1
sc delete "GoodbyeDPI" >nul 2>&1

:: Değişkenleri mühürle (Boşluklu yolları kurtarmak için mutlak yol kullanımı)
SET "EXE_FULL_PATH=%CD%\%_arch%\goodbyedpi.exe"
SET "LIST_FULL_PATH=%CD%\turkey-blacklist.txt"

:: Servis oluşturma (Tüm parametreler 'start' komutuyla birebir eşitlendi)
sc create "GoodbyeDPI" binPath= "\"%EXE_FULL_PATH%\" -5 --set-ttl 5 --blacklist \"%LIST_FULL_PATH%\" --dns-addr 1.1.1.1 --dns-port 53 --dnsv6-addr 2606:4700:4700::1111 --dnsv6-port 53" start= "auto"
sc description "GoodbyeDPI" "Turkiye icin optimize edilmis, oyun dostu internet servisi."
sc start "GoodbyeDPI"

echo.
echo [+] Islem Tamamlandi. Servis basariyla kuruldu ve baslatildi.
timeout /t 3 >nul
POPD