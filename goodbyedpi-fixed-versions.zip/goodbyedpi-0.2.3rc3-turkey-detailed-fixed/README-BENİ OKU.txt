KASPERKSY ANTİVİRÜSÜ HAKKINDA ÖNEMLİ NOT (13.01.2025)

Kaspersky isimli antivirüs yazılımı Rus hükümetiyle olan anlaşmasından dolayı GoodbyeDPI'ın çalışmasına engel olmaktadır. Kaspersky isimli yazılımı kullanıyorsanız, kullandıysanız veya devre dışı halde bile olsa bilgisayarınızda bulunuyorsa lütfen tamamen kaldırın. Bunu yapmadığınız taktirde GoodbyeDPI çok yüksek ihtimalle çalışmayacaktır. Kaspersky yerine alternatif antivirüs yazılımları tercih edebilir ya da Windows Defender kullanabilirsiniz. (Windows Defender 2026 yılı itibariyle kötü amaçlı yazılım ve siteleri engellemekte son derece yeterlidir.) Kaspersky'i GoodbyeDPI ZIP dosyasının indirme işlemi sırasında devre dışı bırakmanız, indirdikten sonra dışlamalara eklemeniz veya devre dışı bırakmanız sorunu çözmeyecektir. GoodbyeDPI'ı doğru şekilde kullanabilmek için Kaspersky isimli antivirüs yazılımından bir şekilde kurtulmalısınız.

GoodbyeDPI — Derin Paket İnceleme (DPI) atlatma aracı (Türkiye versiyonu)

Bu uygulama, Türkiye'de bazı internet servis sağlayıcılarının DNS değişikliğine izin vermemesi sebebiyle, bu durumu bertaraf etmek için asıl proje olan GoodbyeDPI'ın düzenlenmiş bir versiyonudur. Bu yazılım, birçok ISS'da (İnternet Servis Sağlayıcısı) bulunan ve belirli web sitelerine erişimi engelleyen "Derin Paket İnceleme" (DPI) sistemlerini atlatmak için tasarlanmıştır. Bu uygulama kesinlikle bir VPN değildir ve oyunlarda/genel internet kullanımında bir hız değişikliğine sebep olmayacaktır.

VİRÜS & VERİ SIZINTISI & BITCOIN MINING

Program açık kaynak kodlu olduğundan tüm kodu görüp inceleyebilirsiniz. Bazı kullanıcılar VirusTotal'de false positive bildirimi yapsa da bu WinDivert.dll ve WinDivert64.sys dosyalarının fonksiyonlarından dolayı bu şekilde yanlış bir sonuç verebiliyor (bu dosyalar sistemi etkiler). Dilerseniz tüm klasörü ya da .zip dosyasını VirusTotal gibi bir sitede taratıp sonuçları inceleyebilirsiniz.

GOODBYEDPI'I KULLANMAK

GoodbyeDPI'ın Türkiye Fixed-Edition versiyonunu kullanmak için iki yöntem bulunmaktadır.

    Hizmet kurarak kullanma: Yalnızca bir kez hizmeti kurup ardından elle herhangi bir şey çalıştırmaya gerek kalmaksızın bilgisayarınız her yeniden başlatıldığında otomatik olarak çalışır.

    Batch dosyası ile kullanma: Batch dosyası ile kullanmada her defasında elle batch dosyasını başlatarak kullanmanız gerekir (batch penceresi kapatıldığında GoodbyeDPI kullanımına son verilir).

NOT: İndirdiğiniz klasörleri çıkarttığınız konumdan taşımayın. Kurulacak hizmet .cmd dosyasını çalıştırdığınız dosya yolunu kullanacağından eğer dosyaları taşırsanız hizmet çalışmayacaktır.

HİZMET KURARAK KULLANMA (Windows başlatılırken otomatik olarak çalıştırılır)

    Seçiminize göre "goodbyedpi-0.2.3rc3-2-basic-fixed" veya "goodbyedpi-0.2.3rc3-turkey-detailed-fixed" klasörlerinden birine girin.

    Çıkartılan dosyalardan service_install_dnsredir_turkey.cmd dosyasına sağ tıklayarak Yönetici Olarak Çalıştır seçeneğini seçin.

    Açılan konsol penceresinde herhangi bir tuşuna basın. Pencere, hizmet kurulduğunda otomatik olarak kapanacak ve hizmet de otomatik olarak başlayacaktır.

NOT: Bu işlem bilgisayarınıza GoodbyeDPI hizmetini kuracaktır. GoodbyeDPI hizmetini bilgisayarınızdan kaldırmak için çıkarttığınız dosyalar içerisindeki service_remove.cmd dosyasını yönetici olarak çalıştırmanız gerekmektedir.

BATCH DOSYASI İLE KULLANMA (Tek seferlik, pencere kapatıldığında sona erecek şekilde)

    İlgili klasörün içindeki turkey_dnsredir.cmd dosyasına sağ tıklayarak Yönetici Olarak Çalıştır seçeneğini seçin.

SIK KARŞILAŞILAN SORUNLAR

    WinDivert dosyaları bulunamadı hatası: Antivirüs programınıza ayıkladığınız klasörü dışlama/istisna olarak ekleyin. Klasör isimleri: "goodbyedpi-0.2.3rc3-2-basic-fixed" veya "goodbyedpi-0.2.3rc3-turkey-detailed-fixed".

    Hizmetin başlatılmaya çalışıldığında "Dosya yolu bulunamadı" hatası: Bu hata klasörü taşımanız halinde ortaya çıkar. Önce service_remove.cmd dosyasını çalıştırın, sonra yeni konumda tekrar kurulum yapın.

    Bazı sitelerin yavaş açılması/açılmaması sorunu: Belirli siteler yavaş açılıyor ya da hiç açılmıyorsa "detailed-fixed" klasörü içindeki TTL ayarı içermeyen 2 ve 4 numaralı alternatif metodları deneyebilirsiniz.

    Discord hatası: Discord "Update Failed" hatası alıyorsanız "detailed-fixed" klasörü içindeki alternatif yöntemleri (özellikle 2 ve 4) deneyin.

DNS VE PORT'U DÜZENLEME

Farklı bir DNS kullanmak için turkey_dnsredir.cmd ve service_install_dnsredir_turkey.cmd dosyalarını metin düzenleyici ile düzenleyebilirsiniz. Tavsiye edilen: Yandex DNS (77.88.8.8) veya Cloudflare DNS (1.1.1.1).

WinDivert.dll ve WinDivert64.sys DOSYALARINI SİLMEK

Eğer bu dosyaları silmeye çalıştığınızda "Dosya kullanımda" hatası alırsanız, aşağıdaki adımları takip edin:

    Kurduğunuz klasör içindeki service_remove.cmd dosyasını yönetici olarak çalıştırın.

    Bilgisayarınızı yeniden başlatın.

    Yeniden başlattıktan sonra dosyaları sorunsuzca silebilirsiniz.

Hala silinmiyorsa; Komut İstemi'ni (CMD) yönetici olarak açıp şu komutu yazarak sürücüyü manuel olarak durdurmayı deneyebilirsiniz:
sc stop WinDivert

YASAL UYARI

Bu uygulamanın kullanımından doğan her türlü yasal sorumluluk kullanan kişiye aittir. Uygulama yalnızca eğitim ve araştırma amaçları ile yazılmış ve düzenlenmiştir.

Credits: ValdikSS, Çağrı Taşkın, TheTakanosu.